import { existsSync } from 'fs'
import { join } from 'path'
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import { performance } from 'perf_hooks'
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    let old = performance.now()
    let neww = performance.now()
    let speed = (neww - old).toFixed(4)

    const user = await conn.getName(m.sender)
    const fecha = new Date().toLocaleDateString('ar-SA', { 
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
    })
    const hora = new Date().toLocaleTimeString('ar-SA')

    let menuText = `> ꒦꒷𓆩☠️𓆪꒷꒦ ✧ 🜲 𖤐 🜲 ✧ ꒦꒷𓆩☠️𓆪꒷꒦
>
> 🜲⃝☠️ *أهـلاً بـك يـا:* ${user}
> 𖤐⃝🩸 *الـمـسـتـوى:* ${m.sender.split('@')[0]}
>
> ꒷꒦𓂅 ☣️ 𓂅꒦꒷ ✧ 𓆩🩸𓆪 ✧ ꒷꒦𓂅 ☣️ 𓂅꒦꒷
>
> 👁️⃝🩸 *الـبـيـنـق:* ${speed}ms
> ☣️⃝🩸 *الـتـشـغـيـل:* ${await getUptime()}
> 𖤐⃝🩸 *الـتـاريـخ:* ${fecha}
> 👁️⃝☠️ *الـوقـت:* ${hora}
> ☠️⃝🩸 *الـمـطـور:* ༺youssf༻
>
> ꒷꒦𓂅 ☣️ 𓂅꒦꒷ ✧ 𓆩🜲𓆪 ✧ ꒷꒦𓂅 ☣️ 𓂅꒦꒷
>
> ✅⃝🩸 *⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2*
>
> ꒦꒷𓆩☣️𓆪꒷꒦ ✧ 🩸 🜲 🩸 ✧ ꒦꒷𓆩☣️𓆪꒷꒦`

    await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } })

    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/file_000000001a5871f4969d87b797c9b57f.png'
    const channel = 'https://whatsapp.com/channel/0029VbCJtCILI8YQz9VFQQ2w'
    const developerNumber = '201002435496'
    const developerContact = `https://wa.me/${developerNumber}`
    
    const imageRes = await fetch(imageUrl)
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer())
    
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer })
    
    // ⬇️ contextInfo مع القناة الصحيحة
    const contextInfo = {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363408060822145@newsletter',
        newsletterName: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽╳ 𝗕𝗢𝗧𝗦 •',
        serverMessageId: '0'
      }
    }
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '𓆩 ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 𓆪' },
      header: {
        hasMediaAttachment: true,
        subtitle: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
              title: "☠️ الأقـسام الـرئـيـسـيـة",
              sections: [
                {
                  title: " 🜲 عـرض الأقـسـام 🜲 ",
                  rows: [
                    { "title": "🩸 قـسم الأدمن", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق1" },
                    { "title": "☠️ قـسم الاستيكر", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق2" },
                    { "title": "🩸 قـسم الألعاب", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق3" },
                    { "title": "☠️ قـسم التحميلات", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق4" },
                    { "title": "🩸 قـسم الادوات", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق5" },
                    { "title": "☠️ قـسم المانجا", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق6" },
                    { "title": "🩸 قـسم الذكاء", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق7" },
                    { "title": "☠️ قـسم النقابات", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق8" },
                    { "title": "🩸 قـسم الصور", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق9" },
                    { "title": "☠️ قـسم التسليه", "description": "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2", "id": "ق10" }
                  ]
                }
              ]
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🩸 تــنــصــيــب الــبــوت',
              id: 'تنصيب'
            })
          },
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: '☠️ الــقــنــاة الــرســمــيــة',
              url: channel,
              merchant_url: channel
            })
          },
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: '🜲 مــراســلــة ༺youssf༻',
              url: developerContact,
              merchant_url: developerContact
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          limited_time_offer: {
            text: `⚡ ${speed}ms`,
            url: developerContact,
            copy_code: `المطور: +${developerNumber}`,
            expiration_time: Date.now() + 86400000
          },
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            divider_indices: [1, 2, 3, 4, 5, 6, 7, 8, 9, 999],
            list_title: "🩸 قـائـمـة أقـسـام الـبـوت",
            button_title: "☠️ عـرض الأقـسـام"
          },
          tap_target_configuration: {
            description: "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2",
            canonical_url: developerContact,
            domain: "https://wa.me/201002435496",
            button_index: 0
          }
        })
      }
    }

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload)
    
    const fkontak = await makeFkontak()
    
    // ⬇️ إنشاء الرسالة مع contextInfo
    const msg = generateWAMessageFromContent(m.chat, { 
      viewOnceMessage: {
        message: {
          interactiveMessage: interactiveMessage
        }
      }
    }, { 
      userJid: conn.user.jid, 
      quoted: fkontak,
      contextInfo: contextInfo
    })
    
    // ⬇️ إرسال الرسالة
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 🎵 إرسال الصوت بعد القائمة (ptt: true)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    try {
      const audioUrl = 'https://file.garden/aauvg01sjleV_ic1/proooo.opus';
      await conn.sendMessage(m.chat, {
        audio: { url: audioUrl },
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true
      }, { quoted: m });
    } catch (audioErr) {
      console.error('خطأ في تشغيل الصوت:', audioErr);
    }

  } catch (e) {
    console.error('خطأ:', e);
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg')
    const thumb2 = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    }
  } catch {
    return undefined
  }
}

async function getUptime() {
  let totalSeconds = process.uptime()
  let hours = Math.floor(totalSeconds / 3600)
  let minutes = Math.floor((totalSeconds % 3600) / 60)
  let seconds = Math.floor(totalSeconds % 60)
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['الاوامر', 'menu', 'اوامر', 'القائمة', 'منيو']

export default handler
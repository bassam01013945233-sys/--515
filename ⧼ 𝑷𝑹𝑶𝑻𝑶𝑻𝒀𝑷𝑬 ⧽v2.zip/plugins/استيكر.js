import { sticker } from '../Z/sticker.js'

let handler = async (m, { conn }) => {
  // ⬇️ التحقق من وجود صورة أو فيديو
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''

  if (!mime || (!mime.includes('image') && !mime.includes('video'))) {
    return conn.sendMessage(m.chat, { 
      text: '🜲⃝☠️ *الرجاء الرد على صورة أو فيديو لتحويله لملصق*' 
    }, { quoted: m })
  }

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    // ⬇️ تحميل الميديا
    let media = await q.download()
    
    // ⬇️ تحويل لملصق باستخدام دالة sticker
    let stiker = await sticker(media, false, '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', '༺ youssf ༻')
    
    // ⬇️ إرسال الملصق
    await conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m })
    
  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, { 
      text: '❌⃝🩸 *فشل في إنشاء الملصق*\n🜲⃝☠️ *تأكد من تثبيت ffmpeg*' 
    }, { quoted: m })
  }
}

handler.command = ['ستيكر', 'sticker', 'ملصق']
handler.help = ['ستيكر']
handler.tags = ['sticker']

export default handler
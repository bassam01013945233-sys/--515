// plugins/manhwa.js
// الأوامر: .مانهوا، .عرض_مانهوا، .فصل، .تحميل_فصل

import axios from 'axios';
import cheerio from 'cheerio';
import baileys from '@whiskeysockets/baileys';
import JSZip from 'jszip';
import { theme } from '../core/theme.js';

const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = baileys;

const DEFAULT_IMAGE = 'https://i3.wp.com/despair-manga.net/wp-content/uploads/2025/08/0001-1-1.jpg?w=720';
const CACHE_DURATION = 5 * 60 * 1000;
const MAX_IMAGES_PER_CHAPTER = 30;
const REQUEST_TIMEOUT = 30000;
const RETRY_COUNT = 3;
const BASE_URL = 'https://despair-manga.net';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📦 Cache System
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const cache = new Map();

function getCached(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.data;
    }
    return null;
}

function setCached(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔧 Utility Functions
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function fetchWithRetry(url, retries = RETRY_COUNT) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, {
                timeout: REQUEST_TIMEOUT,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'ar,en;q=0.9',
                    'Referer': BASE_URL
                }
            });
            return response;
        } catch (err) {
            if (i === retries - 1) throw err;
            await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        }
    }
}

async function createImageMessage(conn, url) {
    if (!url || typeof url !== "string" || !url.startsWith("http")) return null;
    try {
        const media = await prepareWAMessageMedia({ image: { url } }, { upload: conn.waUploadToServer });
        return media.imageMessage || null;
    } catch {
        return null;
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ℹ️ جلب معلومات المانهوا
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function getMangaInfoData(mangaUrl) {
    const cacheKey = `manga_info_${mangaUrl}`;
    const cached = getCached(cacheKey);
    if (cached) return cached;

    const { data } = await fetchWithRetry(mangaUrl);
    const $ = cheerio.load(data);
    
    const title = $('h1.entry-title').text().trim();
    const altTitle = $('.alternative').text().trim();
    const coverImg = $('.thumb img').attr('src');
    const status = $('.imptdt:contains("Status") i').text().trim();
    const type = $('.imptdt:contains("Type") a').text().trim();
    const views = $('.imptdt:contains("Views") i').text().trim() || 'غير معروف';
    const followers = $('.bmc').text().trim().replace('Followed by ', '').replace(' people', '');
    const rating = $('.rating .num').text().trim() || 'N/A';
    const translationTeam = $('.imptdt:contains("فريق الترجمة") a').text().trim() || 'غير معروف';
    
    const genres = [];
    $('.mgen a').each((i, el) => { genres.push($(el).text().trim()); });
    
    const synopsis = $('.entry-content.entry-content-single').text().trim();
    
    // جلب الفصول
    const chapters = [];
    $('#chapterlist ul li').each((i, el) => {
        const chapterNum = $(el).attr('data-num');
        const chapterUrl = $(el).find('a').attr('href');
        const chapterName = $(el).find('.chapternum').text().trim();
        const chapterDate = $(el).find('.chapterdate').text().trim();
        
        if (chapterUrl && chapterName) {
            chapters.push({
                number: chapterNum,
                name: chapterName,
                url: chapterUrl,
                date: chapterDate
            });
        }
    });
    chapters.reverse();
    
    const result = {
        title, altTitle, coverImg, status, type, views, followers, rating,
        translationTeam, genres, synopsis, chapters, totalChapters: chapters.length
    };
    
    setCached(cacheKey, result);
    return result;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔍 البحث باستخدام API + Carousel
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function searchManga(conn, m, query) {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }); } catch {}
    };

    await react('🔍');

    try {
        const searchUrl = `${BASE_URL}/wp-admin/admin-ajax.php`;
        const formData = new URLSearchParams();
        formData.append('action', 'ts_ac_do_search');
        formData.append('ts_ac_query', query);

        const { data } = await axios.post(searchUrl, formData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        const results = data.series?.[0]?.all || [];

        if (results.length === 0) {
            await react('❌');
            return m.reply(theme.build([
                { type: 'error', text: `❌ لا توجد نتائج لـ: ${query}` },
                { type: 'info', label: 'نصيحة', value: 'جرب كتابة اسم مختلف' }
            ]));
        }

        const cards = [];
        for (const manga of results.slice(0, 8)) {
            const coverUrl = manga.post_image?.match(/https?:\/\/[^"']+\.(jpg|png|webp)/i)?.[0] || DEFAULT_IMAGE;
            const imageMsg = await createImageMessage(conn, coverUrl);
            if (!imageMsg) continue;

            const status = manga.post_status === 'Ongoing' ? '🔄 جاري' : '✅ مكتملة';
            const latest = `📖 الفصل ${manga.post_latest}`;

            cards.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `🌙 *${manga.post_title.substring(0, 35)}*\n${status}\n${latest}\n🏷️ ${manga.post_type}`
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    hasMediaAttachment: true,
                    imageMessage: imageMsg
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                                display_text: '📖 عرض المانجا',
                                id: `.عرض_مانهوا ${manga.post_link}`
                            })
                        }
                    ]
                })
            });
        }

        if (cards.length === 0) {
            await react('⚠️');
            return m.reply('⚠️ حدث خطأ في تحميل الصور، حاول مرة أخرى.');
        }

        const carouselMsg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: theme.build([
                                { type: 'title', text: `نتائج البحث عن: ${query}` },
                                { type: 'info', label: 'العدد', value: results.length.toString() }
                            ])
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: `⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 • بحث متقدم`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
                    })
                }
            }
        }, { quoted: m });

        await conn.relayMessage(m.chat, carouselMsg.message, { messageId: carouselMsg.key.id });
        await react('✅');

    } catch (error) {
        console.error('Search error:', error);
        await react('❌');
        await m.reply(theme.build([
            { type: 'error', text: '❌ فشل في البحث' },
            { type: 'info', label: 'السبب', value: error.message }
        ]));
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📖 عرض معلومات المانجا + قائمة الفصول
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function showMangaInfoWithChapters(conn, m, mangaUrl) {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }); } catch {}
    };

    await react('ℹ️');

    try {
        const manga = await getMangaInfoData(mangaUrl);
        
        const statusText = manga.status === 'Ongoing' ? '🟢 جاري' : manga.status === 'Completed' ? '🔴 مكتمل' : manga.status;
        
        // بناء معلومات المانجا
        const sections = [
            { type: 'title', text: manga.title },
            { type: 'spacer' }
        ];
        
        if (manga.altTitle) sections.push({ type: 'info', label: 'الاسم البديل', value: manga.altTitle });
        
        sections.push(
            { type: 'divider' },
            { type: 'info', label: '📖 النوع', value: manga.type },
            { type: 'info', label: '📊 الحالة', value: statusText },
            { type: 'info', label: '⭐ التقييم', value: manga.rating },
            { type: 'info', label: '👥 المتابعون', value: manga.followers },
            { type: 'info', label: '👁️ المشاهدات', value: manga.views },
            { type: 'info', label: '📚 عدد الفصول', value: manga.totalChapters.toString() }
        );
        
        if (manga.translationTeam && manga.translationTeam !== 'غير معروف') {
            sections.push({ type: 'info', label: '🖋️ فريق الترجمة', value: manga.translationTeam });
        }
        
        if (manga.genres.length > 0) {
            sections.push({ type: 'info', label: '🏷️ التصنيفات', value: manga.genres.join(' • ') });
        }
        
        sections.push({ type: 'divider' });
        
        if (manga.synopsis) {
            const shortSynopsis = manga.synopsis.length > 300 ? manga.synopsis.substring(0, 300) + '...' : manga.synopsis;
            sections.push(
                { type: 'subtitle', text: '📖 القصة' },
                { type: 'line', text: shortSynopsis },
                { type: 'divider' }
            );
        }
        
        const infoText = theme.build(sections);
        
        // إرسال معلومات المانجا مع الصورة
        let coverBuffer = null;
        if (manga.coverImg) {
            try {
                const coverRes = await axios.get(manga.coverImg, { responseType: 'arraybuffer' });
                coverBuffer = coverRes.data;
            } catch(e) {}
        }
        
        if (coverBuffer) {
            await conn.sendMessage(m.chat, {
                image: coverBuffer,
                caption: infoText,
                mimetype: 'image/jpeg'
            }, { quoted: m });
        } else {
            await m.reply(infoText);
        }
        
        // ━━━━━ بعد المعلومات، نرسل قائمة الفصول ━━━━━
        if (manga.chapters.length === 0) {
            await react('⚠️');
            return m.reply(theme.build([
                { type: 'warning', text: '⚠️ لا توجد فصول متاحة حالياً' }
            ]));
        }
        
        // إنشاء أزرار الفصول (قائمة منسدلة)
        const rows = manga.chapters.slice(0, 25).map((ch) => ({
            title: `📖 ${ch.name}`,
            description: `📅 ${ch.date || 'تاريخ غير معروف'}`,
            id: `.فصل ${ch.url}`   // هنا الأمر الجديد .فصل
        }));
        
        const chaptersImageMsg = await createImageMessage(conn, manga.coverImg || DEFAULT_IMAGE);
        
        const interactiveMessage = proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
                text: theme.build([
                    { type: 'title', text: `📚 ${manga.title.substring(0, 35)}` },
                    { type: 'info', label: 'اختر الفصل', value: `📖 ${manga.totalChapters} فصل متاح` }
                ])
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: `⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 • اضغط على الفصل لعرض الصور`
            }),
            header: chaptersImageMsg ? proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: true,
                imageMessage: chaptersImageMsg
            }) : proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [{
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: '📖 قائمة الفصول',
                        sections: [{ title: 'الفصول المتاحة', rows }]
                    })
                }]
            })
        });
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: { interactiveMessage } }
        }, { quoted: m });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await react('✅');
        
    } catch (error) {
        console.error('Manga info error:', error);
        await react('❌');
        await m.reply(theme.build([
            { type: 'error', text: '❌ فشل في جلب المعلومات' },
            { type: 'info', label: 'السبب', value: error.message }
        ]));
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📸 عرض صفحات الفصل
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function getChapterImages(chapterUrl) {
    const cacheKey = `chapter_images_${chapterUrl}`;
    const cached = getCached(cacheKey);
    if (cached) return cached;

    try {
        const { data } = await fetchWithRetry(chapterUrl);
        
        const tsReaderMatch = data.match(/ts_reader\.run\((\{[\s\S]+?\})\)/);
        if (!tsReaderMatch) return [];
        
        const imagesMatch = tsReaderMatch[1].match(/"images":\s*\[([^\]]+)\]/);
        if (!imagesMatch) return [];
        
        let imagesStr = imagesMatch[1].replace(/\n/g, '').replace(/\\/g, '');
        const images = JSON.parse(`[${imagesStr}]`);
        const fullUrls = images.map(img => img.startsWith('http') ? img : `${BASE_URL}${img}`);
        
        setCached(cacheKey, fullUrls);
        return fullUrls;
        
    } catch (error) {
        console.error('Chapter images error:', error);
        return [];
    }
}

async function showChapterPages(conn, m, chapterUrl) {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }); } catch {}
    };

    const startTime = Date.now();
    await react('⏳');
    await m.reply('🌙 *جاري تحميل الصور...* ⭐');

    try {
        const images = await getChapterImages(chapterUrl);

        if (images.length === 0) {
            await react('❌');
            return m.reply(theme.build([
                { type: 'error', text: '❌ لم يتم العثور على صور في هذا الفصل' }
            ]));
        }

        let imagesToSend = images;
        if (images.length > MAX_IMAGES_PER_CHAPTER) {
            await m.reply(theme.build([
                { type: 'warning', text: `⚠️ هذا الفصل كبير (${images.length} صفحة)` },
                { type: 'info', label: 'سيتم إرسال', value: `أول ${MAX_IMAGES_PER_CHAPTER} صفحة فقط` }
            ]));
            imagesToSend = images.slice(0, MAX_IMAGES_PER_CHAPTER);
        }

        await m.reply(theme.build([
            { type: 'info', label: '📸 جاري الإرسال', value: `${imagesToSend.length} صفحة` }
        ]));

        for (let i = 0; i < imagesToSend.length; i++) {
            try {
                await conn.sendMessage(m.chat, {
                    image: { url: imagesToSend[i] },
                    caption: theme.build([
                        { type: 'title', text: `الصفحة ${i+1} من ${imagesToSend.length}` }
                    ])
                }, { quoted: m });
                
                if (i < imagesToSend.length - 1) await new Promise(r => setTimeout(r, 400));
            } catch (err) {
                console.error(`Page ${i + 1} failed:`, err.message);
            }
        }

        const timeSec = ((Date.now() - startTime) / 1000).toFixed(1);
        await m.reply(theme.build([
            { type: 'success', text: `✅ تم إرسال ${imagesToSend.length} صفحة بنجاح` },
            { type: 'info', label: '⏱️ الوقت', value: `${timeSec} ثانية` }
        ]));
        await react('✅');

    } catch (error) {
        console.error('Chapter error:', error);
        await react('❌');
        await m.reply(theme.build([
            { type: 'error', text: '❌ فشل في تحميل الفصل' },
            { type: 'info', label: 'السبب', value: error.message }
        ]));
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📦 تحميل الفصل كاملاً كملف ZIP
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function downloadFullChapter(conn, m, chapterUrl) {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }); } catch {}
    };

    await react('⏳');
    await m.reply('📦 *جاري تجهيز الفصل للتحميل...*');

    try {
        const images = await getChapterImages(chapterUrl);

        if (images.length === 0) {
            throw new Error('لم يتم العثور على صور');
        }

        await m.reply(`📸 *تم العثور على ${images.length} صفحة*\n🔄 جاري إنشاء ملف ZIP...`);

        const zip = new JSZip();

        for (let i = 0; i < images.length; i++) {
            try {
                const imgRes = await axios.get(images[i], { 
                    responseType: 'arraybuffer',
                    timeout: 30000
                });
                zip.file(`page_${String(i + 1).padStart(3, '0')}.webp`, imgRes.data);
            } catch (err) {
                console.error(`Failed to download page ${i + 1}:`, err.message);
            }
        }

        const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
        const fileName = `manhwa_chapter_${Date.now()}.zip`;
        const fileSizeMB = (zipBuffer.length / 1024 / 1024).toFixed(2);

        await conn.sendMessage(m.chat, {
            document: zipBuffer,
            mimetype: 'application/zip',
            fileName: fileName,
            caption: theme.build([
                { type: 'title', text: '📦 الفصل كاملاً' },
                { type: 'info', label: '📄 عدد الصفحات', value: images.length.toString() },
                { type: 'info', label: '📁 الحجم', value: `${fileSizeMB} MB` }
            ])
        }, { quoted: m });

        await react('✅');

    } catch (err) {
        console.error('[Download Chapter] Error:', err);
        await react('❌');
        await m.reply(theme.build([
            { type: 'error', text: '❌ فشل التحميل' },
            { type: 'info', label: 'السبب', value: err.message }
        ]));
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎯 الأمر الرئيسي
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
let handler = async (m, { conn, text, command, usedPrefix }) => {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }); } catch {}
    };

    // أمر المساعدة
    if ((command === 'مانهوا' && !text) || command === 'مساعدة') {
        await react('📚');
        return conn.sendMessage(m.chat, {
            image: { url: DEFAULT_IMAGE },
            caption: theme.build([
                { type: 'title', text: '📚 أوامر المانهوا' },
                { type: 'spacer' },
                { type: 'subtitle', text: '🔍 البحث' },
                { type: 'info', label: usedPrefix + 'مانهوا <اسم>', value: 'البحث عن مانهوا (كاروسيل)' },
                { type: 'spacer' },
                { type: 'subtitle', text: '📖 عرض المانجا' },
                { type: 'info', label: usedPrefix + 'عرض_مانهوا <رابط>', value: 'يعرض معلومات المانوا + قائمة الفصول' },
                { type: 'spacer' },
                { type: 'subtitle', text: '📸 عرض الفصل' },
                { type: 'info', label: usedPrefix + 'فصل <رابط الفصل>', value: 'يعرض صور الفصل مباشرة' },
                { type: 'spacer' },
                { type: 'subtitle', text: '📦 التحميل' },
                { type: 'info', label: usedPrefix + 'تحميل_فصل <رابط الفصل>', value: 'تحميل الفصل كـ ZIP' },
                { type: 'divider' },
                { type: 'info', label: '⚡ مثال', value: `${usedPrefix}مانهوا solo leveling` }
            ])
        }, { quoted: m });
    }

    // البحث
    if (command === 'مانهوا' && text && !text.startsWith('http')) {
        return searchManga(conn, m, text);
    }
    
    // عرض معلومات المانجا + قائمة الفصول
    if (command === 'عرض_مانهوا') {
        if (!text || !text.startsWith('http')) {
            return m.reply(theme.build([
                { type: 'error', text: '⚠️ الاستخدام:' },
                { type: 'info', label: usedPrefix + 'عرض_مانهوا', value: '<رابط المانهوا>' },
                { type: 'info', label: 'مثال', value: `${usedPrefix}عرض_مانهوا https://despair-manga.net/manga/solo-leveling-ragnarok/` }
            ]));
        }
        return showMangaInfoWithChapters(conn, m, text);
    }
    
    // عرض الفصل مباشرة
    if (command === 'فصل') {
        if (!text || !text.startsWith('http')) {
            return m.reply(theme.build([
                { type: 'error', text: '⚠️ الاستخدام:' },
                { type: 'info', label: usedPrefix + 'فصل', value: '<رابط الفصل>' },
                { type: 'info', label: 'مثال', value: `${usedPrefix}فصل https://despair-manga.net/solo-leveling-ragnarok-الفصل-50/` }
            ]));
        }
        return showChapterPages(conn, m, text);
    }
    
    // تحميل الفصل كـ ZIP
    if (command === 'تحميل_فصل' || command === 'zip') {
        if (!text || !text.startsWith('http')) {
            return m.reply(theme.build([
                { type: 'error', text: '⚠️ الاستخدام:' },
                { type: 'info', label: usedPrefix + 'تحميل_فصل', value: '<رابط الفصل>' }
            ]));
        }
        return downloadFullChapter(conn, m, text);
    }
};

handler.command = ['مانهوا', 'عرض_مانهوا', 'فصل', 'تحميل_فصل', 'zip'];
handler.tags = ['manhwa'];
handler.help = ['مانهوا <اسم/رابط>', 'عرض_مانهوا <رابط>', 'فصل <رابط>', 'تحميل_فصل <رابط>'];

export default handler;
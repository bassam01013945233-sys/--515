// plugins/download-snap.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - تحميل من SnapTube/Instagram 📥

import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, args, usedPrefix, command }) => {
    
    // التحقق من وجود رابط
    if (!args[0]) {
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: 'طـريـقـة الاسـتـخـدام' },
            { type: 'subtitle', text: 'يرجى وضع الرابط بعد الأمر' },
            { type: 'divider' },
            { type: 'info', label: 'مثال', value: `${usedPrefix + command} https://www.instagram.com/p/xxxxx` }
        ]), m);
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    await conn.reply(m.chat, theme.build([
        { type: 'title', text: '📥 جـاري الـتـحـمـيـل' },
        { type: 'subtitle', text: '⏳ يرجى الانتظار...' }
    ]), m);

    try {
        const apiUrl = `https://tanjirodev.online/api/down-snap?url=${encodeURIComponent(args[0])}`;
        
        let res = await fetch(apiUrl);
        let json = await res.json();

        // التحقق من نجاح العملية
        if (json.status !== "success" || !json.results || json.results.length === 0) {
            throw new Error('تعذر العثور على روابط تحميل لهذا الرابط');
        }

        let downloadUrl = json.results[0].url;
        let title = json.title || 'SnapTube Downloader';

        // إرسال الفيديو
        await conn.sendMessage(m.chat, { 
            video: { url: downloadUrl }, 
            caption: theme.build([
                { type: 'title', text: '✅ تـم الـتـحـمـيـل' },
                { type: 'subtitle', text: title },
                { type: 'divider' },
                { type: 'info', label: 'بواسطة', value: json.dev || '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ ✨' }
            ])
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        await conn.reply(m.chat, theme.build([
            { type: 'title', text: '❌ خـطـأ' },
            { type: 'subtitle', text: e.message || 'حدث خطأ أثناء التحميل' },
            { type: 'divider' },
            { type: 'line', text: 'تأكد من صحة الرابط وحاول مرة أخرى' }
        ]), m);
    }
};

handler.help = ['snap', 'snaptube', 'انستا'];
handler.tags = ['downloader'];
handler.command = /^(snap|snaptube|انستا|انستاتيوب)$/i;

export default handler;
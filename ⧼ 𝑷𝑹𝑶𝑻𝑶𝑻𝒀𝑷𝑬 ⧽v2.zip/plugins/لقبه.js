// plugins/lakabe.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - عرض لقب عضو آخر في المجموعة 👥

let handler = async (m, { conn, text }) => {
    try {
        let mentionedJid;

        // تحديد العضو المستهدف
        if (m.quoted && m.quoted.sender) {
            mentionedJid = m.quoted.sender;
        } else if (m.mentionedJid && m.mentionedJid[0]) {
            mentionedJid = m.mentionedJid[0];
        } else if (text) {
            const number = text.replace(/[^0-9]/g, '');
            if (number) {
                mentionedJid = number + '@s.whatsapp.net';
            }
        }

        if (!mentionedJid) {
            return m.reply(`✍️ *طريقة الاستخدام:*\n.لقبه @العضو\nأو رد على رسالة العضو`);
        }

        // التأكد من وجود قاعدة البيانات
        if (!global.db?.data?.users) {
            return m.reply(`❌ قاعدة البيانات غير جاهزة`);
        }

        const users = global.db.data.users;
        const groupId = m.chat;
        const user = users[mentionedJid];

        if (!user || !user.groups || !user.groups[groupId]?.name) {
            let memberName = mentionedJid.split('@')[0];
            try {
                const nameFromConn = await conn.getName(mentionedJid);
                if (nameFromConn) memberName = nameFromConn;
            } catch(e) {}
            
            return m.reply(`❌ العضو ${memberName} لا يملك لقباً مسجلاً في هذه المجموعة.`);
        }

        const nickname = user.groups[groupId].name;
        
        let memberName = mentionedJid.split('@')[0];
        try {
            const nameFromConn = await conn.getName(mentionedJid);
            if (nameFromConn) memberName = nameFromConn;
        } catch(e) {}

        let msg = `╭━━ 👥 *لقب العضو* ━━⃝💙
│
│ 👤 *العضو:* ${memberName}
│ 🏷️ *لقبه:* ${nickname}
│
╰━━━━━━━━━━━━━⃝💙`;

        await conn.sendMessage(m.chat, { text: msg, mentions: [mentionedJid] }, { quoted: m });

    } catch (err) {
        console.error('لقبه error:', err);
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

handler.help = ['لقبه'];
handler.tags = ['unions'];
handler.command = /^(لقبه|nickname|lakabe)$/i;
handler.group = true;

export default handler;
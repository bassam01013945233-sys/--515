// plugins/q2-sticker.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم الاستيكر 🎨

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const user = await conn.getName(m.sender);
    
    // ⬇️ أوامر قسم الاستيكر (بدون وصف)
    let menuText = `> ${theme.divider}
>
> 🜲⃝☠️ *أهـلاً بـك يـا:* ${user}
> 𖤐⃝🩸 *الـقـسـم:* قسم الاستيكر
>
> ${theme.smallDivider}
>
> 👁️⃝🩸 *الأوامر المتاحة:*
>
> 🎨⃝🩸 *.ملصق* 
> 🎨⃝🩸 *.ملصقات* 
> 🎨⃝🩸 *.ستيكر* 
>
> ${theme.smallDivider}
>
> 📌 *طريقة الاستخدام:*
> 👁️⃝🩸 أرسل الصورة مع الأمر
> 👁️⃝🩸 أو قم بالرد على صورة بالأمر
>
> ${theme.endDivider}`;

    await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

    // 🔁 الصورة الجديدة
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/df774970b6d8419a88664f73eacfb6f4.png';
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
      header: {
        hasMediaAttachment: true,
        subtitle: '🎨 قـسم الاسـتـيـكـر',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "🎨 قـسم الاسـتـيـكـر",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'حدث خطأ في تحميل قسم الاستيكر' }
      ])
    }, { quoted: m });
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق2'];
handler.tags = ['main'];
handler.command = ['ق2'];

export default handler;
// plugins/kablod.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - كابلود 🤖

import WebSocket from 'ws';
import axios from 'axios';
import { theme } from '../core/theme.js';

class Copilot {
    constructor() {
        this.conversationId = null
        this.headers = {
            origin: 'https://copilot.microsoft.com',
            'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36'
        }
    }

    async createConversation() {
        let { data } = await axios.post('https://copilot.microsoft.com/c/api/conversations', null, { headers: this.headers })
        this.conversationId = data.id
        return this.conversationId
    }

    async chat(message) {
        if (!this.conversationId) await this.createConversation()
        return new Promise((resolve, reject) => {
            const ws = new WebSocket(`wss://copilot.microsoft.com/c/api/chat?api-version=2&features=-,ncedge,edgepagecontext&setflight=-,ncedge,edgepagecontext&ncedge=1`, { headers: this.headers })
            let response = ''
            
            const timeout = setTimeout(() => {
                ws.terminate()
                reject(new Error('الوقت انتهى، حاول مرة أخرى'))
            }, 60000)

            ws.on('open', () => {
                ws.send(JSON.stringify({
                    event: 'send',
                    mode: 'chat',
                    conversationId: this.conversationId,
                    content: [{ type: 'text', text: message }],
                    context: {}
                }))
            })

            ws.on('message', chunk => {
                try {
                    const parsed = JSON.parse(chunk.toString())
                    if (parsed.event === 'appendText') response += parsed.text || ''
                    if (parsed.event === 'done') {
                        clearTimeout(timeout)
                        resolve(response)
                        ws.close()
                    }
                } catch (e) {}
            })

            ws.on('error', (err) => {
                clearTimeout(timeout)
                reject(err)
            })
        })
    }
}

let handler = async (m, { conn, text }) => {
    try {
        if (!text) {
            return m.reply(theme.build([
                { type: 'title', text: '🤖 كابلود' },
                { type: 'spacer' },
                { type: 'info', label: 'الاستخدام', value: '.كابلود <سؤالك>' },
                { type: 'info', label: 'مثال', value: '.كابلود من أنت؟' }
            ]));
        }

        await conn.sendMessage(m.chat, { react: { text: '🧠', key: m.key } });
        await m.reply('🧠 *كابلود يفكر...* 💙');

        let copilot = new Copilot();
        let res = await copilot.chat(text);

        if (!res || res.trim() === '') {
            throw new Error('لم يتم الحصول على رد');
        }

        let cleanResponse = res.trim();

        await conn.sendMessage(m.chat, {
            text: `╭━━ 🤖 *كابلود* ━━⃝💙
│
│ 💬 *سؤالك:* ${text}
│
│ 📝 *الرد:*
│ ${cleanResponse}
│
╰━━━━━━━━━━━━━⃝💙`
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('كابلود error:', e);
        await m.reply(theme.build([
            { type: 'error', text: '❌ حدث خطأ في كابلود' },
            { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' },
            { type: 'warning', text: 'حاول مرة أخرى لاحقاً' }
        ]));
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}

handler.help = ['كابلود <سؤال>'];
handler.command = ['كابلود', 'kablod'];
handler.tags = ['ai'];

export default handler;
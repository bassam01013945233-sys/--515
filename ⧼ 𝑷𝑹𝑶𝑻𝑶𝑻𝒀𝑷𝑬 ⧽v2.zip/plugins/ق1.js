import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const user = await conn.getName(m.sender)
    
    // ⬇️ أوامر قسم الأدمن
    let menuText = `*╭━ 𝑨𝑫𝑴𝑰𝑵 𝑺𝑬𝑪𝑻𝑰𝑶𝑵 ━⃝🩸*\n`
    menuText += `*│* 👑⃝🩸 *اهـلاً:* ${user}\n`
    menuText += `*╰━━━━━━━━━━━⃝☠️*\n\n`
    
    menuText += `*╭━━ 𝐀𝐃𝐌𝐈𝐍 ━━⃝🩸*\n`
    menuText += `*│* *『 ❐╎ منشن ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ جروب ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ طرد ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ انذار ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ الغاء_انذار ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ انذارات ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ لينك ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ اعفاء ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ ترقيه ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ المتصلين ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ تجديد ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ مخفي ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ حذف ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ كتم ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ فك_الكتم ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ منع_الخليج ⃝🩸 』*\n`
    menuText += `*│* *『 ❐╎ منع_الروابط ⃝🩸 』*\n`
    menuText += `*╰━━━━━━━━━━━⃝☠️*\n\n`
    
    menuText += ` ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2`

    await conn.sendMessage(m.chat, { react: { text: '👮‍♂️', key: m.key } })

    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/file_0000000013c8724698353ba4d26bbd69.png'
    const imageRes = await fetch(imageUrl)
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer())
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer })
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '© ʙʏ ༺ youssf ༻' },
      header: {
        hasMediaAttachment: true,
        subtitle: '👮‍♂️ قـسم الأدمن ⃝🩸',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: 'الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: 'المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "👮‍♂️ قـسم الأدمن",
            button_title: "خـيـارات"
          }
        })
      }
    }

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    })
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, { text: `❌ حصل خطأ في تحميل قسم الأدمن` }, { quoted: m })
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg')
    const thumb2 = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    }
  } catch {
    return undefined
  }
}

handler.help = ['ق1']
handler.tags = ['main']
handler.command = ['ق1']

export default handler
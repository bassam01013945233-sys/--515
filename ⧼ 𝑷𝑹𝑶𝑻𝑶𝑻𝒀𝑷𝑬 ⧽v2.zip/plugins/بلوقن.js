// plugins/بلوقن.js (القسم المعدل - زر نسخ فقط)
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - إدارة البلوقنات (مع زر نسخ فقط) 📦

import fs from "fs";
import path from "path";
import { downloadContentFromMessage, generateWAMessageFromContent, proto } from "@whiskeysockets/baileys";
import { theme } from '../core/theme.js';

const TAGS_FILE = "./src/database/plugin-tags.json";

const SECTIONS = {
    ai:         "🤖 الذكاء الاصطناعي",
    downloader: "🔗 التحميلات",
    games:      "🎮 الألعاب",
    sticker:    "🖼️ الصور والستيكر",
    group:      "👥 المجموعات",
    tools:      "🔧 الأدوات",
    economy:    "🏦 الاقتصاد",
    protection: "🛡️ الحماية",
    fun:        "🎉 ترفيه",
    owner:      "⚜️ المطور",
    main:       "🏠 عام",
};

function loadTags() {
    try {
        if (fs.existsSync(TAGS_FILE)) return JSON.parse(fs.readFileSync(TAGS_FILE, "utf-8"));
    } catch {}
    return {};
}

function saveTags(data) {
    try {
        const dir = path.dirname(TAGS_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(TAGS_FILE, JSON.stringify(data, null, 2), "utf-8");
    } catch {}
}

function detectTag(code) {
    const match = code.match(/handler\.tags\s*=\s*\[['"`]([^'"`]+)['"`]\]/);
    if (match) return match[1].toLowerCase();
    return null;
}

const waitingSections = new Map();

let handler = async (m, { conn, args, usedPrefix }) => {

    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }); } catch {}
    };

    const pluginsDir = path.dirname(global.__filename(import.meta.url, true));
    const currentFile = path.basename(global.__filename(import.meta.url, true));
    const getPlugins = () => fs.readdirSync(pluginsDir).filter(f => f.endsWith(".js") && f !== currentFile);

    const action = (args[0] || "").toLowerCase();
    const tags = loadTags();

    if (waitingSections.has(m.sender) && /^[0-9]+$/.test(m.text?.trim())) {
        const session = waitingSections.get(m.sender);
        const secKeys = Object.keys(SECTIONS);
        const choice = parseInt(m.text.trim()) - 1;

        if (choice < 0 || choice >= secKeys.length) {
            return m.reply("❌ رقم غير صحيح — اختار رقم من القائمة");
        }

        const chosenTag = secKeys[choice];
        const savePath = path.join(session.pluginsDir, session.fileName);
        fs.writeFileSync(savePath, session.code, "utf-8");

        tags[session.fileName] = chosenTag;
        saveTags(tags);

        waitingSections.delete(m.sender);
        await react("✅");
        return m.reply(`✅ تم ${session.isEdit ? "تعديل" : "إضافة"} البلوقن *${session.fileName}*\n📂 القسم: ${SECTIONS[chosenTag]}`);
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  عرض — إرسال الكود مع زر نسخ فقط
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if (/^(عرض|show|get)$/i.test(action)) {
        const nameArg = args.slice(1).join(" ").trim();
        if (!nameArg) return m.reply(`📄 الاستخدام:\n${usedPrefix}بلوقن عرض <اسم>`);

        const fileName = nameArg.replace(/\.js$/i, "") + ".js";
        const filePath = path.join(pluginsDir, fileName);
        if (!fs.existsSync(filePath)) {
            await react("❌");
            return m.reply(`❌ الملف *${fileName}* غير موجود`);
        }

        const code = fs.readFileSync(filePath, "utf-8");
        const tag = tags[fileName] || "main";
        const sectionName = SECTIONS[tag] || "عام";

        await react("📄");

        // ✅ زر النسخ فقط (بدون زر إغلاق)
        const copyButton = {
            name: 'cta_copy',
            buttonParamsJson: JSON.stringify({
                display_text: '📋 نسخ الكود',
                copy_code: code
            })
        };

        const menuText = `> ${theme.divider}
> 
> 🜲⃝☠️ *${fileName}*
> 𖤐⃝🩸 القسم: ${sectionName}
> 📦 الحجم: ${(code.length / 1024).toFixed(2)} KB
> 
> 👁️⃝🩸 اضغط على الزر أدناه لنسخ الكود
> 
> ${theme.endDivider}`;

        const interactiveMessage = {
            body: { text: menuText },
            footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
            nativeFlowMessage: {
                buttons: [copyButton]
            }
        };

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject(interactiveMessage)
                }
            }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        return;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  لست — عرض كل البلوقنات
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if (/^(لست|list)$/i.test(action)) {
        const plugins = getPlugins();
        if (!plugins.length) {
            await react("📦");
            return m.reply("📂 لا يوجد أي بلوقنات");
        }

        const grouped = {};
        for (const f of plugins) {
            const tag = tags[f] || "main";
            if (!grouped[tag]) grouped[tag] = [];
            grouped[tag].push(f.replace(".js", ""));
        }

        const lines = [`> ${theme.divider}`, `> 🜲⃝☠️ *قـائـمـة الـبـلـوقـنـات*`, `> ${theme.smallDivider}`];
        for (const [tag, cmds] of Object.entries(grouped)) {
            const sec = SECTIONS[tag] || `📌 ${tag}`;
            lines.push(`> ✦ *${sec}*`);
            cmds.forEach((c, i) => lines.push(`> ${i + 1}. ${c}`));
            lines.push(`> ${theme.smallDivider}`);
        }
        lines.push(`> المجموع: ${plugins.length} بلوقن`);
        lines.push(`> ${theme.endDivider}`);

        await react("📦");
        return m.reply(lines.join("\n"));
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  نقل — نقل بلوقن لقسم تاني
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if (/^(نقل|move)$/i.test(action)) {
        const nameArg = args.slice(1).join(" ").trim();
        if (!nameArg) return m.reply(`📂 الاستخدام:\n${usedPrefix}بلوقن نقل <اسم>`);

        const fileName = nameArg.replace(/\.js$/i, "") + ".js";
        if (!fs.existsSync(path.join(pluginsDir, fileName))) {
            await react("❌");
            return m.reply(`❌ الملف *${fileName}* غير موجود`);
        }

        const currentTag = tags[fileName] || "main";
        const secKeys = Object.keys(SECTIONS);
        const lines = [
            `> ${theme.divider}`,
            `> 🜲⃝☠️ *${fileName}*`,
            `> القسم الحالي: ${SECTIONS[currentTag]}`,
            `> ${theme.smallDivider}`,
            `> اختار القسم الجديد:`,
            `>`
        ];
        secKeys.forEach((k, i) => lines.push(`> ${i + 1}. ${SECTIONS[k]}`));
        lines.push(`>`, `> أرسل الرقم للتأكيد`);
        lines.push(`> ${theme.endDivider}`);

        waitingSections.set(m.sender, {
            fileName,
            code: fs.readFileSync(path.join(pluginsDir, fileName), "utf-8"),
            pluginsDir,
            isMove: true,
        });

        await react("📂");
        return m.reply(lines.join("\n"));
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  حذف — حذف البلوقن
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if (/^(حذف|delete|del|remove)$/i.test(action)) {
        const nameArg = args.slice(1).join(" ").trim();
        if (!nameArg) return m.reply(`🗑️ الاستخدام:\n${usedPrefix}بلوقن حذف <اسم>`);

        const fileName = nameArg.replace(/\.js$/i, "") + ".js";
        const filePath = path.join(pluginsDir, fileName);
        if (!fs.existsSync(filePath)) {
            await react("❌");
            return m.reply(`❌ الملف *${fileName}* غير موجود`);
        }

        const oldTag = tags[fileName] || "main";
        fs.unlinkSync(filePath);
        if (global.plugins?.[fileName]) delete global.plugins[fileName];
        delete tags[fileName];
        saveTags(tags);

        await react("🗑️");
        return m.reply(`🗑️ تم حذف *${fileName}*\nكان في قسم: ${SECTIONS[oldTag] || oldTag}`);
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  اضف — إضافة بلوقن جديد
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if (/^(اضف|اضافه|اضافة|add)$/i.test(action)) {
        const quoted = m.quoted;
        if (!quoted) {
            await react("❌");
            return m.reply("❌ رد على كود أو ملف البلوقن");
        }

        let code = "";
        let fileName = "";

        const docMsg = quoted.message?.documentMessage ||
            quoted.message?.documentWithCaptionMessage?.message?.documentMessage || null;

        if (docMsg) {
            let buffer;
            try { buffer = await quoted.download(); } catch {
                try {
                    const stream = await downloadContentFromMessage(docMsg, "document");
                    const chunks = [];
                    for await (const c of stream) chunks.push(c);
                    buffer = Buffer.concat(chunks);
                } catch (e) {
                    await react("❌");
                    return m.reply("❌ فشل تحميل الملف: " + e.message);
                }
            }
            const baseName = (docMsg.fileName || `plugin_${Date.now()}`).replace(/\.js$/i, "");
            fileName = `${baseName}.js`;
            code = buffer.toString("utf-8");
        } else {
            code = quoted.text || quoted.body || "";
            if (!code.trim()) {
                await react("❌");
                return m.reply("❌ الرسالة مش فيها كود");
            }
            const matchName = code.match(/handler\.command\s*=\s*\/\^\(?([^)\/|\\s]+)/) ||
                              code.match(/command\s*:\s*['"`]([^'"`]+)['"`]/);
            fileName = matchName ? `${matchName[1].trim()}.js` : `plugin_${Date.now()}.js`;
        }

        const detectedTag = detectTag(code);

        if (detectedTag && SECTIONS[detectedTag]) {
            const savePath = path.join(pluginsDir, fileName);
            const isEdit = fs.existsSync(savePath);
            fs.writeFileSync(savePath, code, "utf-8");
            tags[fileName] = detectedTag;
            saveTags(tags);

            await react("✅");
            return m.reply(`✅ تم ${isEdit ? "تعديل" : "إضافة"} *${fileName}*\n📂 القسم (تلقائي): ${SECTIONS[detectedTag]}`);
        }

        const secKeys = Object.keys(SECTIONS);
        const lines = [
            `> ${theme.divider}`,
            `> 🜲⃝☠️ *${fileName}*`,
            `> ${theme.smallDivider}`,
            `> مش قادر أحدد القسم تلقائياً.`,
            `> اختار القسم المناسب:`,
            `>`
        ];
        secKeys.forEach((k, i) => lines.push(`> ${i + 1}. ${SECTIONS[k]}`));
        lines.push(`>`, `> أرسل الرقم للتأكيد`);
        lines.push(`> ${theme.endDivider}`);

        waitingSections.set(m.sender, { fileName, code, pluginsDir });

        await react("❓");
        return m.reply(lines.join("\n"));
    }

    // القائمة الافتراضية
    await react("📦");
    const helpText = `> ${theme.divider}
> 
> 🜲⃝☠️ *إدارة الـبـلـوقـنـات*
> 𖤐⃝🩸 ${usedPrefix}بلوقن لست
> > قائمة كل البلوقنات بأقسامها
> 
> ${usedPrefix}بلوقن عرض <اسم>
> > عرض الكود مع زر نسخ
> 
> ${usedPrefix}بلوقن اضف (رد على كود)
> > إضافة بلوقن جديد
> 
> ${usedPrefix}بلوقن نقل <اسم>
> > نقل بلوقن لقسم تاني
> 
> ${usedPrefix}بلوقن حذف <اسم>
> > حذف بلوقن نهائياً
> 
> ${theme.endDivider}`;

    return m.reply(helpText);
};

handler.help = ["بلوقن لست", "بلوقن عرض", "بلوقن اضف", "بلوقن نقل", "بلوقن حذف"];
handler.tags = ["owner"];
handler.command = /^(بلوقن|plugin|plugins)$/i;
handler.owner = true;

export default handler;
// plugins/voice-reply.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - الرد الصوتي 🎙️

let handler = async (m, { conn }) => {
  try {
    let audioUrl = 'https://file.garden/aauvg01sjleV_ic1/pro.opus'

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true,
      fileName: 'PROTOTYPE.opus'
    }, { quoted: m })
    
  } catch (err) {
    console.error(err)
    m.reply('❌ حدث خطأ أثناء إرسال الرد الصوتي.')
  }
}

handler.customPrefix = /^(بوت|يا بوت)$/i
handler.command = new RegExp()

export default handler
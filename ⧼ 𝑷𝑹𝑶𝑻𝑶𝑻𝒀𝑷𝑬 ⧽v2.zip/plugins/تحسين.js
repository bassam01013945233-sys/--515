// plugins/hd.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - تحسين جودة الصور 🖼️

import { theme } from '../core/theme.js';
import sharp from 'sharp';

let handler = async (m, { conn, usedPrefix, command }) => {
  
  const quoted = m.quoted ? m.quoted : m;
  const mime = quoted.mimetype || quoted.msg?.mimetype || '';

  // التحقق من وجود صورة
  if (!/image\/(jpe?g|png|webp)/i.test(mime)) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    return conn.reply(m.chat, theme.build([
      { type: 'title', text: 'طـريـقـة الاسـتـخـدام' },
      { type: 'subtitle', text: 'قم بإرسال صورة أو الرد على صورة لتحسين جودتها' },
      { type: 'divider' },
      { type: 'info', label: 'مثال', value: `${usedPrefix + command} (مع صورة)` }
    ]), m);
  }

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    // تحميل الصورة
    let media = await quoted.download();
    
    // استخدام sharp لتحسين الجودة وزيادة الدقة
    const image = sharp(media);
    const metadata = await image.metadata();
    
    // حساب الأبعاد الجديدة (زيادة 2x)
    const newWidth = metadata.width * 2;
    const newHeight = metadata.height * 2;
    
    // الحجم القديم
    const oldSize = (media.length / 1024).toFixed(2);
    
    // تحسين الجودة وزيادة الدقة
    const enhancedBuffer = await image
      .resize(newWidth, newHeight, {
        kernel: sharp.kernel.lanczos3, // أفضل خوارزمية للتحسين
        fit: 'fill'
      })
      .sharpen() // زيادة الحدة
      .jpeg({ quality: 95, chromaSubsampling: '4:4:4' }) // جودة عالية
      .toBuffer();
    
    // الحجم الجديد
    const newSize = (enhancedBuffer.length / 1024).toFixed(2);
    
    await conn.sendMessage(m.chat, {
      image: enhancedBuffer,
      caption: theme.build([
        { type: 'title', text: '✅ تـم تـحـسـيـن الـصـورة' },
        { type: 'subtitle', text: 'تم تحسين جودة الصورة بنجاح' },
        { type: 'divider' },
        { type: 'info', label: '📐 الـدقـة', value: `${metadata.width}x${metadata.height} → ${newWidth}x${newHeight}` },
        { type: 'info', label: '📦 الـحـجـم', value: `${oldSize} KB → ${newSize} KB` },
        { type: 'divider' },
        { type: 'line', text: '⚡ تمت المعالجة بواسطة PROTO TYPE ⚡' }
      ])
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    await conn.reply(m.chat, theme.build([
      { type: 'title', text: '❌ فـشـل الـتـحـسـيـن' },
      { type: 'subtitle', text: err.message || 'حدث خطأ أثناء تحسين الصورة' },
      { type: 'divider' },
      { type: 'line', text: '💡 تأكد من صحة الصورة وحاول مرة أخرى' }
    ]), m);
  }
};

handler.help = ['hd'];
handler.tags = ['tools'];
handler.command = /^(تحسين|ادي_اتش|جوده|hd|mejorar)$/i;

export default handler;
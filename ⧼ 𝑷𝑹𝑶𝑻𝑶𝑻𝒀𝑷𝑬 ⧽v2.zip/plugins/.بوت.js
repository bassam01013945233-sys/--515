// plugins/bot.js
// ⧼ اسيا ⧽v1 - أمر البوت 🤖

import { join } from 'path'
import os from 'os'
import fs from 'fs'

global.loading = async (m, conn, isDone = false) => {
  await conn.sendMessage(m.chat, {
    react: { text: '', key: m.key }
  })
}

global.config = global.config || { 
  author: '201142182793', 
  watermark: '⧼ اسيا ⧽ v1' 
}

// صورة واحدة فقط (بدون مصفوفة)
const imageUrl = 'https://litter.catbox.moe/2al7cp.jpg'

let handler = async (m, { conn }) => {
  try {
    await global.loading(m, conn)

    const teks = `╭━━ 🤖 *الـبـوت* ━━⃝💙
│
│ ✨ *مرحباً بك في عالم اسيا ~ v1*
│ 👤 *المستخدم:* @${m.sender.split('@')[0]}
│
│ 💡 *أنا هنا لمساعدتك 24/7*
│
╰━━━━━━━━━━━━━⃝💙`

    await conn.sendMessage(m.chat, {
      product: {
        productImage: { url: imageUrl },
        productId: global.config.author,
        title: '*⧼ اسيا ⧽ v1*',
        description: 'بوت متكامل للخدمات والترفيه',
        currencyCode: 'USD',
        priceAmount1000: '1000000',
        retailerId: global.config.author,
        productImageCount: 1
      },
      businessOwnerJid: '201142182793@s.whatsapp.net',
      caption: teks,
      footer: global.config.watermark,
      interactiveButtons: [
        {
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({
            display_text: '📋 الـقـائـمـة',
            id: '.الاوامر'
          })
        }
      ],
      mentions: [m.sender]
    })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, { text: '❌ حصل خطأ' })
  } finally {
    await global.loading(m, conn, true)
  }
}

handler.help = ['بوت']
handler.tags = ['main']

// يرد على: بوت  |  .بوت فقط
handler.customPrefix = /^(\.بوت|بوت)$/i
handler.command = new RegExp

export default handler
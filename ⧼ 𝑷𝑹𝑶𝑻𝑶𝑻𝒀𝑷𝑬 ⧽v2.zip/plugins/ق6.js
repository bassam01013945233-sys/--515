// commands/ق6.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - قسم المانجا والأنمي 🎬

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const user = await conn.getName(m.sender);
    
    // ⬇️ أوامر قسم المانجا والأنمي
    let menuText = `> ${theme.divider}
>
> 🜲⃝☠️ *أهـلاً بـك يـا:* ${user}
> 𖤐⃝🩸 *الـقـسـم:* قسم المانجا والأنمي
>
> ${theme.smallDivider}
>
> 👁️⃝🩸 *الأوامر المتاحة:*
>
> 🎬⃝🎌 *${_p}انمي* 
> 📖⃝🎌 *${_p}مانجا_توك* 
> 📚⃝🎌 *${_p}مانهوا*  
>
> ${theme.smallDivider}
>
> 📌 *طريقة الاستخدام:*
> 👁️⃝🩸 اكتب الأمر واتبع التعليمات
>
> ${theme.endDivider}`;

    await conn.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });

    // صورة قسم المانجا والأنمي
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/file_0000000031f0720a8f9dc5ef4fe42bab.png';
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
      header: {
        hasMediaAttachment: true,
        subtitle: '🎬 قـسـم المانجا والأنمي',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "🎬 قـسـم المانجا والأنمي",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'حدث خطأ في تحميل قسم المانجا والأنمي' }
      ])
    }, { quoted: m });
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق6'];
handler.tags = ['main'];
handler.command = ['ق6'];

export default handler;
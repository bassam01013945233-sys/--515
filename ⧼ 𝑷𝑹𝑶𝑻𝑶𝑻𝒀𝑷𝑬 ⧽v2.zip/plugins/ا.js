// plugins/lid.js
// ⧼ اسيا ⧽v1 - عرض Lid المستخدم 🆔

let handler = async (m, { conn }) => {
    
    try {
        // الحصول على Lid المستخدم (نفس الطريقة التي تظهر في حدث الانضمام)
        let userJid = m.sender;
        
        // استخراج Lid (الجزء قبل @)
        let lid = userJid.split('@')[0].replace(/[^0-9]/g, '');
        
        let msg = `╭━━ 🆔 *الـ L i d* ━━⃝💙
│
│ 🆔 *Lid:* ${lid}
│
╰━━━━━━━━━━━━━⃝💙`;
        
        await conn.sendMessage(m.chat, { text: msg }, { quoted: m });
        await conn.sendMessage(m.chat, { react: { text: '🆔', key: m.key } });
        
    } catch (error) {
        console.error('خطأ:', error);
        await m.reply(`❌ حدث خطأ: ${error.message}`);
    }
};

handler.command = /^(lid|معرفي|ليدي)$/i;

export default handler;
// امر رابط الجروب - لجلب رابط دعوة المجموعة

const handler = async (m, { conn, isAdmin, isBotAdmin, usedPrefix, command }) => {
  try {
    // التحقق من أن الأمر يستخدم داخل مجموعة
    if (!m.isGroup) {
      return m.reply('❌ هذا الأمر يستخدم فقط داخل المجموعات')
    }

    // التحقق من صلاحيات المستخدم (أدمن المجموعة)
    if (!isAdmin) {
      return global.dfail('admin', m, conn)
    }

    // التحقق من صلاحيات البوت (أدمن المجموعة)
    if (!isBotAdmin) {
      return global.dfail('botAdmin', m, conn)
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    // جلب رابط الدعوة
    let inviteCode = await conn.groupInviteCode(m.chat)
    let inviteLink = 'https://chat.whatsapp.com/' + inviteCode

    let successText = `> ꒦꒷𓆩✅𓆪꒷꒦
> 
> 🜲⃝☠️ *رابـط الـمـجـمـوعـة*
> 👁️⃝🩸 ${inviteLink}
> 
> ⚠️ ملاحظة: الرابط صالح لمدة 72 ساعة
> 
> ꒦꒷𓆩☣️𓆪꒷꒦ ✧ 🩸 𖤐 🜲 ✧ ꒦꒷𓆩☣️𓆪꒷꒦
> 
> 𓆩⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 𓆪`

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
    await m.reply(successText)

  } catch (e) {
    console.error('خطأ في جلب رابط المجموعة:', e)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    m.reply(`❌ *فشل جلب الرابط:* قد لا يملك البوت صلاحية "الحصول على رابط الدعوة" أو أن المجموعة لا تسمح بذلك.`)
  }
}

handler.command = /^(لينك|رابط_الجروب|invite|getlink)$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler
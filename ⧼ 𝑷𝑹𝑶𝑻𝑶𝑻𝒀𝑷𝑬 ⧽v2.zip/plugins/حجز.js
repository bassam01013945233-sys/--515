// plugins/unions.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - نظام إدارة الألقاب في المجموعات 👥

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const groupId = m.chat;
    
    // التأكد من وجود قاعدة البيانات
    if (!global.db.data) global.db.data = {};
    if (!global.db.data.users) global.db.data.users = {};
    
    let users = global.db.data.users;

    if (!users[m.sender]) users[m.sender] = {};
    if (!users[m.sender].groups) users[m.sender].groups = {};

    const user = users[m.sender];

    try {
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 1. حجز اللقب ✍️
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (command === 'حجز_لقب') {
            if (!text) {
                return m.reply(`✍️ *يرجى كتابة اللقب!*\nمثال: ${usedPrefix + command} الأسطورة`);
            }

            if (user.groups[groupId]?.name) {
                return m.reply(`🛠️ لديك لقب محجوز بالفعل: "${user.groups[groupId].name}"`);
            }

            // التحقق من تكرار اللقب
            for (let key in users) {
                if (users[key].groups?.[groupId]?.name?.toLowerCase() === text.toLowerCase()) {
                    return m.reply(`❌ هذا اللقب محجوز مسبقاً!`);
                }
            }

            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            
            user.groups[groupId] = { 
                name: text, 
                regTime: Date.now(), 
                registered: true 
            };
            
            // حفظ في قاعدة البيانات
            if (global.db.writeData) {
                await global.db.writeData('users', m.sender, user).catch(() => {});
            }
            
            let successMsg = `╭━━ 👥 *حجز لقب* ━━⃝💙
│
│ ✅ *تم حجز اللقب بنجاح*
│
│ 🏷️ *اللقب:* ${text}
│ 👤 *بواسطة:* ${m.pushName || m.sender.split('@')[0]}
│ 📅 *التاريخ:* ${new Date().toLocaleDateString('ar-EG')}
│
╰━━━━━━━━━━━━━⃝💙`;

            await conn.sendMessage(m.chat, { text: successMsg }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 2. قائمة الألقاب المحجوزة 📋
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        else if (command === 'الالقاب_المحجوزه') {
            let reservedNames = [];
            let mentions = [];

            for (let key in users) {
                const u = users[key];
                if (u.groups?.[groupId]?.name) {
                    reservedNames.push(`🏷️ *${u.groups[groupId].name}* ⇽ @${key.split('@')[0]}`);
                    mentions.push(key);
                }
            }

            if (reservedNames.length === 0) {
                return m.reply(`⏳ لا توجد ألقاب محجوزة حتى الآن.`);
            }

            let listMsg = `╭━━ 👥 *قائمة الألقاب المحجوزة* ━━⃝💙
│
${reservedNames.map((n, i) => `│ ${i + 1}. ${n}`).join('\n')}
│
│ 📊 *المجموع:* ${reservedNames.length} لقب
│
╰━━━━━━━━━━━━━⃝💙`;

            await conn.sendMessage(m.chat, { text: listMsg, mentions: mentions }, { quoted: m });
        }

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 3. إلغاء حجز اللقب 🗑️
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        else if (command === 'الغاء_حجز') {
            if (!user.groups?.[groupId]?.name) {
                return m.reply(`🛠️ أنت لا تملك لقباً لإلغائه.`);
            }

            const oldName = user.groups[groupId].name;
            delete user.groups[groupId];

            // حفظ التغيير في قاعدة البيانات
            if (global.db.writeData) {
                await global.db.writeData('users', m.sender, user).catch(() => {});
            }

            let cancelMsg = `╭━━ 👥 *إلغاء حجز لقب* ━━⃝💙
│
│ ✅ *تم إلغاء حجز اللقب*
│
│ 🏷️ *اللقب السابق:* ${oldName}
│ 👤 *بواسطة:* ${m.pushName || m.sender.split('@')[0]}
│
╰━━━━━━━━━━━━━⃝💙`;

            await conn.sendMessage(m.chat, { text: cancelMsg }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        }

    } catch (err) {
        console.error('Unions error:', err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

// إعدادات الأوامر
handler.help = ['حجز_لقب', 'الالقاب_المحجوزه', 'الغاء_حجز'];
handler.tags = ['unions'];
handler.command = /^(حجز_لقب|الالقاب_المحجوزه|الغاء_حجز)$/i;
handler.group = true;
handler.botAdmin = true;

export default handler;
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, args, usedPrefix, command, isAdmin, isOwner }) => {
    // التحقق من أن المستخدم مشرف أو مالك
    if (!isAdmin && !isOwner) {
        const responseText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *هذا الأمر مخصص للمشرفين فقط*
> 
> ${theme.endDivider}`;
        return conn.reply(m.chat, responseText, m);
    }

    // إذا كان المستخدم ضغط زر "قفل" أو "فتح"
    if (args[0] === 'قفل' || args[0] === 'فتح') {
        let isClose = {
            'فتح': 'not_announcement',
            'قفل': 'announcement',
        }[args[0]];

        try {
            await conn.groupSettingUpdate(m.chat, isClose);
            
            const responseText = isClose === 'announcement'
                ? `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم قـفـل الـمـجـمـوعـة*
> 🔒 *الجميع لا يستطيع الكلام الآن*
> 
> ${theme.endDivider}`
                : `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم فـتـح الـمـجـمـوعـة*
> 🔓 *الجميع يستطيع الكلام الآن*
> 
> ${theme.endDivider}`;
            
            return conn.reply(m.chat, responseText, m);
        } catch (e) {
            console.error(e);
            const errorText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *حدث خطأ أثناء تعديل إعدادات المجموعة*
> 
> ${theme.endDivider}`;
            return conn.reply(m.chat, errorText, m);
        }
    }

    // في حالة لم يتم تحديد "قفل" أو "فتح" → نرسل الأزرار
    try {
        const thumbnail = await prepareWAMessageMedia(
            { image: { url: "https://file.garden/aauvg01sjleV_ic1/64927a556db42e5c1e82e704751d3594.jpg" } },
            { upload: conn.waUploadToServer }
        );

        const dataMessage = `> ${theme.divider}
> 
> 🜲⃝☠️ *الـتـحـكـم فـي الـمـجـمـوعـة*
> 𖤐⃝🩸 *اختر إجراء من الأزرار أدناه*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *قفل:* يمنع الأعضاء من الكلام
> 👁️⃝🩸 *فتح:* يسمح للجميع بالكلام
> 
> ${theme.endDivider}`;

        let buttons = [
            {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: '🔒 قفل المجموعة',
                    id: `${usedPrefix}جروب قفل`
                })
            },
            {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: '🔓 فتح المجموعة',
                    id: `${usedPrefix}جروب فتح`
                })
            }
        ];

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: dataMessage },
                        footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
                        header: {
                            hasMediaAttachment: true,
                            imageMessage: thumbnail.imageMessage,
                        },
                        nativeFlowMessage: {
                            buttons: buttons,
                            messageParamsJson: "",
                        },
                    },
                },
            },
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        console.error(e);
        const errorText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *حدث خطأ أثناء إنشاء الأزرار*
> 
> ${theme.endDivider}`;
        conn.reply(m.chat, errorText, m);
    }
};

handler.help = ['جروب <قفل/فتح>'];
handler.tags = ['group'];
handler.command = /^(جروب|group)$/i;
handler.botAdmin = true;
handler.group = true;

export default handler;
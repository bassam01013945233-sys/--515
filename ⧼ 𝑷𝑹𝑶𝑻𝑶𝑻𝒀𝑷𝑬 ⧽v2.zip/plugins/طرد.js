// plugins/kick.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - أمر الطرد 🚫

import { theme } from '../core/theme.js';

let handler = async (m, { conn }) => {
  
  // أرقام المطورين (محظور طردهم)
  const developerNumbers = ['201090224383@s.whatsapp.net', '201002435496@s.whatsapp.net']

  // التحقق من وجود منشن أو رد
  if (!m.mentionedJid?.[0] && !m.quoted) {
    return conn.reply(m.chat, theme.build([
      { type: 'title', text: 'طـريـقـة الاسـتـخـدام' },
      { type: 'subtitle', text: 'قم بمنشن الشخص المراد طرده' },
      { type: 'divider' },
      { type: 'line', text: 'مثال: .طرد @user' },
      { type: 'line', text: 'أو قم بالرد على رسالة العضو' }
    ]), m);
  }

  const user = m.mentionedJid?.[0] || m.quoted.sender

  // منع طرد المطورين
  if (developerNumbers.includes(user)) {
    return conn.reply(m.chat, theme.build([
      { type: 'title', text: '⚠️ تـنـبـيـه' },
      { type: 'subtitle', text: 'لا يمكنك طرد مطور البوت' }
    ]), m, { mentions: [user] });
  }

  // تنفيذ الطرد
  await conn.groupParticipantsUpdate(m.chat, [user], 'remove')

  // رسالة النجاح
  await conn.reply(m.chat, theme.build([
    { type: 'title', text: '✅ تـم الـطـرد' },
    { type: 'subtitle', text: 'تم طرد العضو بنجاح' },
    { type: 'divider' },
    { type: 'info', label: 'الـعـضـو', value: '@' + user.split('@')[0] },
    { type: 'info', label: 'بـواسـطـة', value: '@' + m.sender.split('@')[0] },
    { type: 'divider' },
    { type: 'line', text: '🚫 تم إخراج العضو من المجموعة' }
  ]), m, { mentions: [m.sender, user] });
}

handler.help = ['kick @user']
handler.tags = ['group']
handler.command = ['kick', 'طرد']
handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler;
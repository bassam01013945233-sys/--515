// plugins/game-rps-simple.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - لعبة حجر/ورق/مقص 🪨📄✂️

import { theme } from '../core/theme.js';

let cooldowns = {};

let handler = async (m, { conn, text, usedPrefix, command }) => {

  await conn.sendMessage(m.chat, { react: { text: '🎮', key: m.key } });

  if (!text) {
    return conn.reply(m.chat, theme.build([
      { type: 'title', text: 'لـعـبـة حـجـر/ورق/مـقـص' },
      { type: 'subtitle', text: 'اختر أحد الخيارات التالية:' },
      { type: 'divider' },
      { type: 'info', label: '🪨 حجر', value: `${usedPrefix}${command} حجر` },
      { type: 'info', label: '📄 ورق', value: `${usedPrefix}${command} ورق` },
      { type: 'info', label: '✂️ مقص', value: `${usedPrefix}${command} مقص` }
    ]), m);
  }

  if (cooldowns[m.sender] && cooldowns[m.sender] > Date.now()) {
    let remainingTime = Math.ceil((cooldowns[m.sender] - Date.now()) / 1000);
    return conn.reply(m.chat, `⏰ انتظر ${remainingTime} ثانية`, m);
  }

  let botChoice = Math.random();
  if (botChoice < 0.34) botChoice = 'حجر';
  else if (botChoice > 0.34 && botChoice < 0.67) botChoice = 'مقص';
  else botChoice = 'ورق';

  let userChoice = text.toLowerCase();
  if (!['حجر', 'ورق', 'مقص'].includes(userChoice)) {
    return conn.reply(m.chat, '❌ اختر: حجر، ورق، أو مقص', m);
  }

  let result = '';
  if (userChoice === botChoice) result = 'تعادل 🤝';
  else if (
    (userChoice === 'حجر' && botChoice === 'مقص') ||
    (userChoice === 'مقص' && botChoice === 'ورق') ||
    (userChoice === 'ورق' && botChoice === 'حجر')
  ) result = 'فوز 🎉';
  else result = 'خسارة 😢';

  conn.reply(m.chat, theme.build([
    { type: 'title', text: result === 'فوز 🎉' ? 'فـــائـــز 🥳' : (result === 'خسارة 😢' ? 'خـــســـارة 💔' : 'تــعــادل 🤝') },
    { type: 'divider' },
    { type: 'info', label: 'أنت', value: userChoice },
    { type: 'info', label: 'البوت', value: botChoice },
    { type: 'divider' },
    { type: 'line', text: result }
  ]), m);

  cooldowns[m.sender] = Date.now() + 5000;
};

handler.command = /^(لعبة|حجر|ورق|مقص|rps)$/i;
handler.tags = ['game'];

export default handler;
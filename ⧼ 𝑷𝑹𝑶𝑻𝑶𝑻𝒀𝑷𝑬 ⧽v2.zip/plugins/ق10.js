// plugins/q10-entertainment.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم الترفيه والتسلية 🎉

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '🫪', key: m.key } });

        const user = await conn.getName(m.sender);
        
        // الصورة الجديدة لقسم الترفيه
        const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/file_00000000c1407243921bb6a473d43b26.png';
        
        const imageRes = await fetch(imageUrl);
        const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
        const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });

        let menuText = `*╭━ 𝐄𝐍𝐓𝐄𝐑𝐓𝐀𝐈𝐍𝐌𝐄𝐍𝐓 ━━⃝💜*\n`
        menuText += `*│* *『 ❐╎ زوجني ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ ورع ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ اهبل ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ خروف ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ جميل ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ تحدي ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ فزوره ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ حرب ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ صفع ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ شخصيه ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ نصايح ⃝💜 』*\n`
        menuText += `*│* *『 ❐╎ متفجرات ⃝💜 』*\n`
        menuText += `*╰━━━━━━━━━━━━━⃝🍒*\n\n`

        menuText += `> 𖤐⃝🎉 *مرحباً ${user}، هذا قسم الترفيه والتسلية*`;

        const nativeFlowPayload = {
            body: { text: menuText },
            footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 🎉' },
            header: {
                hasMediaAttachment: true,
                subtitle: '🎉 قـسـم الـتـرفـيـه',
                imageMessage: media.imageMessage
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔙 الـعـودة للـقـائـمـة',
                            id: '.الاوامر'
                        })
                    },
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '👑 الـمـطـور',
                            id: '.المطور'
                        })
                    }
                ],
                messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                        in_thread_buttons_limit: 1,
                        list_title: "🎉 قـسـم الـتـرفـيـه",
                        button_title: "خـيـارات"
                    }
                })
            }
        };

        const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
        const fkontak = await makeFkontak();
        
        const msg = generateWAMessageFromContent(m.chat, { 
            viewOnceMessage: {
                message: {
                    interactiveMessage: interactiveMessage
                }
            }
        }, { 
            userJid: conn.user.jid, 
            quoted: fkontak 
        });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error('خطأ في قسم الترفيه:', e);
        await conn.sendMessage(m.chat, { 
            text: theme.build([
                { type: 'error', text: '❌ حدث خطأ في تحميل قسم الترفيه' },
                { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' }
            ])
        }, { quoted: m });
    }
}

async function makeFkontak() {
    try {
        const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
        const thumb2 = Buffer.from(await res.arrayBuffer());
        return {
            key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
            message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
            participant: '0@s.whatsapp.net'
        };
    } catch {
        return undefined;
    }
}

handler.help = ['ق10'];
handler.tags = ['main'];
handler.command = ['ق10', 'entertainment', 'ترفيه', 'تسلية'];

export default handler;
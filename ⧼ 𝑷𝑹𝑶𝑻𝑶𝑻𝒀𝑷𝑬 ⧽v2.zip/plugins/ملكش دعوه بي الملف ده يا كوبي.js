// commands/terminal.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - تنفيذ أوامر السيرفر 💻

import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';
import { theme } from '../core/theme.js';

const exec = promisify(_exec).bind(cp);

let handler = async (m, { conn, isOwner, command, text, usedPrefix, args, isROwner }) => {
    // فقط المطور يمكنه استخدام هذا الأمر
    if (!isROwner) {
        return m.reply(theme.build([
            { type: 'title', text: '⛔ خـطأ' },
            { type: 'error', text: 'هذا الأمر مخصص للمطور فقط' }
        ]));
    }
    
    if (global.conn.user.jid != conn.user.jid) {
        return m.reply(theme.build([
            { type: 'title', text: '⛔ خـطأ' },
            { type: 'error', text: 'هذا الأمر يعمل فقط على البوت الرئيسي' }
        ]));
    }
    
    if (!text) {
        return m.reply(theme.build([
            { type: 'title', text: '💻 تـنـفـيـذ الأمـر' },
            { type: 'subtitle', text: 'لتنفيذ أوامر في السيرفر' },
            { type: 'divider' },
            { type: 'info', label: 'الاستخدام', value: `$ الأمر` },
            { type: 'info', label: 'مثال', value: `$ ffmpeg -version` },
            { type: 'info', label: 'مثال', value: `$ ls -la` }
        ]));
    }
    
    await m.react('⏳');
    
    let o;
    try {
        o = await exec(command.trimStart() + ' ' + text.trimEnd());
    } catch (e) {
        o = e;
    } finally {
        const { stdout, stderr } = o;
        let result = '';
        
        if (stdout && stdout.trim()) {
            result += `📤 *الخرج:*\n\`\`\`${stdout.trim().slice(0, 1900)}\`\`\`\n`;
        }
        if (stderr && stderr.trim()) {
            result += `⚠️ *الأخطاء:*\n\`\`\`${stderr.trim().slice(0, 1900)}\`\`\`\n`;
        }
        if (!result) {
            result = '✅ تم التنفيذ但没有产出';
        }
        
        await m.react('✅');
        await m.reply(theme.build([
            { type: 'title', text: '💻 نـتـيـجـة الأمـر' },
            { type: 'divider' },
            { type: 'line', text: result }
        ]));
    }
};

// البادئة $ هي اللي تشغل الأمر
handler.customPrefix = /^[$]/;
handler.command = new RegExp;

export default handler;
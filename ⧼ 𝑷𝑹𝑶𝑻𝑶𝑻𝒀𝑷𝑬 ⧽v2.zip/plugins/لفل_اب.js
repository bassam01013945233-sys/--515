// plugins/qaweni.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - أمر المطور (ترقية الحساب) 👑

let handler = async (m, { conn }) => {

    // ✅ رقم المطور (ضع رقمك هنا)
    const DEVELOPER_NUMBER = '201002435496';
    const senderNumber = m.sender.split('@')[0];
    
    // التحقق من هوية المطور
    if (senderNumber !== DEVELOPER_NUMBER) {
        return m.reply(
`╭━━ 👑 *غير مصرح لك* ━━⃝💙
│
│ ❌ *هذا الأمر مخصص للمطور فقط*
│ 👤 *المطور:* +${DEVELOPER_NUMBER}
│
╰━━━━━━━━━━━━━⃝💙`
        );
    }

    // التأكد من وجود قاعدة بيانات المستخدم
    if (!global.db.data.users) global.db.data.users = {};
    if (!global.db.data.users[m.sender]) global.db.data.users[m.sender] = {};

    let user = global.db.data.users[m.sender];

    // منح قيم المطور
    user.money = 999999999999;
    user.exp = 999999999;
    user.level = 9999;
    user.limit = Infinity;
    user.premium = true;
    user.role = '👑 الـمـطـوّر الـمـطـلـق';

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });

    // رسالة التأكيد
    m.reply(
`╭━━ 👑 *تـم الـتـرقـيـة* ━━⃝💙
│
│ ✅ *تم ترقية حسابك إلى مطور مطلق*
│
│ 💰 *النقود:* غير محدود
│ 🧪 *الخبرة:* أقصى حد
│ 📈 *المستوى:* 9999
│ ⭐ *الرتبة:* 👑 المطور المطلق
│
╰━━━━━━━━━━━━━⃝💙

⚡ *⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2*`
    );
};

handler.help = ['قويني'];
handler.tags = ['owner'];
handler.command = /^(قويني|لفل_اب|powerup|ترقية|تطوير)$/i;
handler.owner = true;

export default handler;
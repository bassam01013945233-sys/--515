// plugins/anime-edit.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - فيديوهات أنمي عشوائية 🎬

import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

// كلمات البحث العشوائية
const SEARCH_KEYWORDS = [
    'anime edit',
    'naruto edit',
    'jjk edit',
    'demon slayer edit',
    'nikola tesla edit',
    'chainsaw man edit',
    'solo leveling edit',
    'bleach edit',
    'red dead 2 edit',
    'guts edit'
];

// القنوات للمعاودة التوجيه
const CHANNELS = [
    {
        jid: '120363426261588703@newsletter',
        name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽Xcodes'
    },
    {
        jid: '120363408060822145@newsletter',
        name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽╳ 𝗕𝗢𝗧𝗦 •'
    }
];

let handler = async (m, { conn, text }) => {

    await conn.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });

    // اختيار قناة عشوائية للتوجيه
    const randomChannel = CHANNELS[Math.floor(Math.random() * CHANNELS.length)];

    // اختيار كلمة بحث عشوائية
    let searchQuery = SEARCH_KEYWORDS[Math.floor(Math.random() * SEARCH_KEYWORDS.length)];

    try {
        const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(searchQuery)}&count=20`;
        
        const res = await fetch(apiUrl, {
            headers: { 
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 30000
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();
        
        if (!data?.data?.videos || data.data.videos.length === 0) {
            throw new Error('لا توجد فيديوهات');
        }

        const validVideos = data.data.videos.filter(v => v.play || v.hdplay);
        
        if (validVideos.length === 0) throw new Error('لا توجد فيديوهات صالحة');

        const randomIndex = Math.floor(Math.random() * validVideos.length);
        const video = validVideos[randomIndex];
        
        const videoUrl = video.hdplay || video.play;
        const title = video.title || 'Anime Edit';
        const author = video.author?.unique_id || video.author?.nickname || 'غير معروف';

        if (!videoUrl) throw new Error('رابط الفيديو غير موجود');

        // إرسال الفيديو مع contextInfo لإظهاره كمعاد توجيه من قناة
        await conn.sendMessage(m.chat, { 
            video: { url: videoUrl },
            ptv: true,
            caption: theme.build([
                { type: 'title', text: '🎬 فـيـديـو أنـمـي' },
                { type: 'divider' },
                { type: 'info', label: 'الـمـطـور', value: '༺youssf༻' }
            ]),
            contextInfo: {
                isForwarded: true,
                forwardingScore: 999,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: randomChannel.jid,
                    newsletterName: randomChannel.name,
                    serverMessageId: '0'
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error("خطأ:", e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await conn.reply(m.chat, theme.build([
            { type: 'title', text: '❌ فـشـل الـتـحـمـيـل' },
            { type: 'subtitle', text: 'حدث خطأ أثناء جلب الفيديو' },
            { type: 'divider' },
            { type: 'line', text: 'حاول مرة أخرى لاحقاً' }
        ]), m);
    }
};

handler.help = ['انمي'];
handler.tags = ['anime'];
handler.command = /^(تست|anime|انم)$/i;

export default handler;
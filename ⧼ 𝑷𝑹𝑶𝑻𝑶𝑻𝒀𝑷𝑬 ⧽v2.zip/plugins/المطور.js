// plugins/owner.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: 'https://file.garden/aauvg01sjleV_ic1/pro.opus' },
        mimetype: 'audio/mp4',
        ptt: true 
      },
      { quoted: m }
    );
    await new Promise(resolve => setTimeout(resolve, 1000));
  } catch (e) {}

  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2
ORG:⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2
TITLE:Metatron Executioner of Michael
EMAIL;type=INTERNET:go588288@gmail.com
TEL;type=CELL;waid=201002435496:+201002435496
ADR;type=WORK:;;2-chōme-7-5 Fuchūchō;Izumi;Osaka;594-0071;Japan
URL;type=WORK:https://www.instagram.com/go24.q?igsh=MWdoYWtjZWNnMGhncQ==
X-WA-BIZ-NAME:⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2
X-WA-BIZ-DESCRIPTION:✧･ﾟ: ✧･ﾟ: 𝑰’𝒎 𝒏𝒐𝒕 𝒉𝒖𝒎𝒂𝒏 𝒂𝒏𝒚𝒎𝒐𝒓𝒆 :･ﾟ✧:･ﾟ✧
X-WA-BIZ-HOURS:Mo-Su 00:00-23:59
END:VCARD`

  let qkontak = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast"
    },
    message: {
      contactMessage: {
        displayName: "⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2",
        vcard
      }
    }
  }

  await conn.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2',
        contacts: [{ vcard }]
      }
    },
    { quoted: qkontak }
  )
}

handler.help = ['owner', 'creator']
handler.tags = ['main']
handler.command = /^(owner|creator|المطورين|المطور|مطور|مطورك|مطوري|creador)$/i

export default handler